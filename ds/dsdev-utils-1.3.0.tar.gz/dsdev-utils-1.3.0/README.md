[![PyPI version](https://badge.fury.io/py/dsdev-utils.svg)](http://badge.fury.io/py/dsdev-utils)
![](https://github.com/Digital-Sapphire/dsdev-utils/actions/workflows/main.yaml/badge.svg)

# DSDev Utils
##### Various utility function I seem to always use

###### [Change Log](https://github.com/JMSwag/dsdev-utils/docs/changelog.md "Change Log")

## To Install

#### From pip:

    $ pip install dsdev-utils

#### From source:

    $ python setup.py install
